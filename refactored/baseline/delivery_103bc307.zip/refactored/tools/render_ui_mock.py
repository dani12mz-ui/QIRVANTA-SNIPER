#!/usr/bin/env python3
"""HTML layout prototype only. NOT a TradingView/Pine screenshot or renderer parity test."""
from pathlib import Path
import json,math,os,shutil
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
HTML='''<!doctype html><html lang="bg"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>
*{box-sizing:border-box}body{margin:0;background:#0c1420;color:#e5ebf4;font:14px Arial,sans-serif;overflow:hidden}.banner{height:34px;background:#38270b;color:#ffdc87;text-align:center;padding:9px;font-size:12px;letter-spacing:.3px}.header{height:48px;padding:16px 14px;border-bottom:1px solid #243245}.header span{float:right;color:#9baec4;font-size:11px}#chart{position:absolute;top:82px;left:0;width:100%;height:calc(100vh - 145px)}#panel{position:absolute;top:96px;left:10px;max-width:calc(100vw - 65px);border:1px solid #3a4a60;border-collapse:collapse;font-size:16px;box-shadow:0 6px 20px #0004}td{padding:7px 8px;background:#101c2c;vertical-align:middle;white-space:nowrap}tr:nth-child(even) td{background:#172337}td:first-child{color:#9badc6;font-size:14px}td:last-child{color:#e2ecff}.caution{color:#ffd27c!important}.down{color:#ff8b99!important}.muted{color:#aabbd1!important}footer{position:fixed;bottom:0;left:0;right:0;height:60px;padding:11px 12px;background:#101c2c;border-top:1px solid #273a51;font-size:11px;color:#aabbd1;line-height:18px}#testnote{position:fixed;bottom:72px;left:12px;max-width:calc(100% - 24px);font-size:10px;color:#93a6be}.tag{font-size:12px;background:#1c8e76;color:#fff;padding:5px 7px;border-radius:3px;position:absolute;right:65px;bottom:200px;line-height:16px}
</style><div class="banner">МАКЕТ — НЕ TRADINGVIEW / НЕ ПАЗАРНИ ДАННИ</div><div class="header">QIRVANTA · M15 <span>Наблюдение</span></div><svg id="chart"></svg><table id="panel"><tr><td>Контекст</td><td class="down">15 ↓ / 240 ↑</td></tr><tr><td>Етап</td><td class="caution">ПРОДАЙ · Пробив</td></tr><tr><td>Липсва</td><td class="caution">НЕВАЛИДИРАН МОДЕЛ</td></tr><tr><td>План</td><td>О 4073.210 / SL 4082.272<br>TP1 4064.148</td></tr><tr><td>Свещ</td><td class="muted">15:15 · НОВИНИ: РЪЧНО</td></tr></table><div class="tag">ПРОДАЙ · Пробив<br>МОДЕЛ / НЕВАЛИД.</div><div id="testnote">Нивата и свещите са пример за разположение.<br>Реалният Pine изглед изисква проверка в TradingView.</div><footer>Само анализ и предупреждения · MT5 не е свързан.<br>Отделен изглед за статистика; без потвърдена доходност.</footer><script>
const svg=document.getElementById('chart');const w=window.innerWidth,h=window.innerHeight-145;svg.setAttribute('viewBox',`0 0 ${w} ${h}`);let s='';for(let y=20;y<h;y+=65)s+=`<line x1="0" y1="${y}" x2="${w}" y2="${y}" stroke="#203044" stroke-width=".5"/>`;const n=Math.floor(w/16)-3;for(let i=0;i<n;i++){let x=10+i*16,base=h*.46+Math.sin(i*.43)*45+i*2;let up=i%3!==0;let ch=12+(i*7)%23;s+=`<line x1="${x}" y1="${base-15}" x2="${x}" y2="${base+ch+12}" stroke="${up?'#32b39c':'#cf6978'}"/><rect x="${x-4}" y="${base}" width="8" height="${ch}" fill="${up?'#32b39c':'#cf6978'}"/>`;}svg.innerHTML=s;
</script></html>'''
def main():
    html=ROOT/'previews/mobile_layout_mock.html';html.write_text(HTML)
    results=[]
    with sync_playwright() as p:
        executable=os.environ.get('CHROMIUM_PATH') or shutil.which('chromium') or shutil.which('chromium-browser')
        options={'headless':True}
        if executable:options['executable_path']=executable
        browser=p.chromium.launch(**options)
        for width,height in [(390,844),(430,932),(1440,900)]:
            page=browser.new_page(viewport={'width':width,'height':height},device_scale_factor=1)
            page.set_content(HTML);page.wait_for_timeout(100)
            report=page.evaluate('''() => {const p=document.getElementById('panel').getBoundingClientRect();return {panel:{left:p.left,right:p.right,top:p.top,bottom:p.bottom},viewport:{w:innerWidth,h:innerHeight},rowCount:document.querySelectorAll('#panel tr').length,documentOverflow:document.documentElement.scrollWidth>innerWidth,cellOverflow:[...document.querySelectorAll('#panel td')].some(x=>x.scrollWidth>x.clientWidth+1)}}''')
            report['size']=f'{width}x{height}';report['within_viewport']=report['panel']['left']>=0 and report['panel']['right']<=width and report['panel']['bottom']<=height;report['status']='HTML_MOCK_ONLY_NOT_PINE_RUNTIME'
            page.screenshot(path=str(ROOT/f'previews/mock_{width}x{height}.png'));page.close();results.append(report)
        browser.close()
    out={'status':'HTML_LAYOUT_CHECK_ONLY','tradingview_rendering':'UNVERIFIED','checks':results}
    (ROOT/'reports/mobile_mock.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
    assert all(x['within_viewport'] and not x['documentOverflow'] and not x['cellOverflow'] and x['rowCount']==5 for x in results)
if __name__=='__main__':main()
